#!/bin/bash
# -*- ENCODING: UTF-8 -*-

echo Ejecucion de docker postgresql
sleep 2s
sudo su
systemctl stop postgresql
sudo docker-compose up --build
